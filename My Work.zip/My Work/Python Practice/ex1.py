##Exercise 1
print "Hello"
print "something"
print "this is quite a fun"
print 'I dont know'
print "why can't u behave in a way I'd like 'you' to behave"
print 'I "said" do not touch this.'


##Exercise 2
print 'Is it greater?', 5 > -2
print "Is it smaller?", -2 < -5
print "Now I ll count the eggs"
print 3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6
print 10.5
print 9.8
print 0.20
print 10.5 + 9.8 + 4.5 - 24.5 / 0.3


##Exercise 3
cars = 100
space_in_a_car = 4
drivers = 30
passengers = 90
cars_not_driven = cars - drivers
cars_driven = drivers
carpool_capacity = cars_driven * space_in_a_car
average_passengers_per_car = passengers / cars_driven
print "There are", cars, "cars available."
print "There are only", drivers, "drivers available."
print "There will be", cars_not_driven, "empty cars today."
print "We can transport", carpool_capacity, "people today."
print "We have", passengers, "to carpool today."
print "We need to put about", average_passengers_per_car, "in each car."

##Exercise 5
my_name = 'Name'
my_age = 20
my_height = 74 #in inches
my_weight = 180 #lbs
my_eyes = 'Black'
my_teeth = 'White'
my_hair = 'Black'
print "Let's talk about %s." % my_name
print "He's %d inches tall." % my_height
print "He weighs %d pounds." % my_weight
print "He's got %s eyes and %s hairs" % (my_eyes, my_hair)
print "If I add %d, %d and %d, I will get %d" % (my_age, my_height, my_weight, my_age + my_height + my_weight)

##Exercise 6
x = "There are %d types of people" %10
binary = "binary"
do_not = "don't"
y = "Those who know %s and those who %s." %(binary, do_not)

print x
print y

print "I said: %s" %x
print "I also said: %s" %y

hilarious = False
joke_evaluation = "Isn't that joke funny! %r"

print joke_evaluation %hilarious

y = "I want to concatenate "
z = "two strings."
a = "Excuse me! What did I "
b = "just say"
print y + z + a + b

##Exercise 7
print "Its fleece was white as %s." % "snow"

end1 = "C"
end2 = "h"
end3 = "e"
end4 = "e"
end5 = "s"
end6 = "e"
end7 = "B"
end8 = "u"
end9 = "r"
end10 = "g"
end11 = "e"
end12 = "r"

# watch that comma at the end.  try removing it to see what happens
print end1 + end2 + end3 + end4 + end5 + end6,
print end7 + end8 + end9 + end10 + end11 + end12
