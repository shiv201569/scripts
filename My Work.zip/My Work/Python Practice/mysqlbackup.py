#!/usr/bin/python

###########################################################
#
# This python script is used for mysql databases backup
# using mysqldump and gzip utility.
#
# Written by : Shivam Agrawal
# Company : domain Ltd
# Created date: Jan 07, 2019
# Last modified: Aug 17, 2019
# Tested with : Python 2.7.15 & Python 3.5
# Script Revision: 1.0
#
##########################################################

# Import required python libraries

import sys, os, datetime, json, logging, time, re, getopt
import subprocess as sp

flag = 0
# MySQL database details to which backup to be done. Make sure below user having enough privileges to take databases backup.
# To take multiple databases backup, create any file like /backup/dbnames.txt and put databases names one on each line and assigned to DB_NAME variable.

DB_HOST = 'localhost'
DB_USER = 'root'
DB_USER_PASSWORD = 'Sqlr00t@devCrv'
DBS = 'metastore'
BACKUP_PATH = '/backup/dbbackup'
LOG_PATH = '/backup/log'
HDFS_PATH = '/backup/dbbackup'

# Getting current DateTime to create the separate backup folder like "20180817-123433".
DATETIME = time.strftime('%Y%m%d-%H%M%S')
TODAYBACKUPPATH = BACKUP_PATH + '/' + DATETIME

def create_db_backups(DBS,BACKUP_PATH,DB_USER,DB_USER_PASSWORD):
        logger = logging.getLogger("default")
        logger.info("Beginning the MYSQL database for: %s using %s user." % (DBS , DB_USER))
        if not(os.path.exists(TODAYBACKUPPATH)):
                p = sp.Popen("mkdir -p "+TODAYBACKUPPATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus = p.wait()
        sql_file = TODAYBACKUPPATH + '/' +DBS+"_backup.sql"
        if os.path.exists(BACKUP_PATH):
                p = sp.Popen("mysqldump -h " + DB_HOST + " -u " + DB_USER + " -p" + DB_USER_PASSWORD + " " + DBS + " > "+sql_file, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus = p.wait()
                if restatus == 0:
                        logger.info("MYSQL database backup for %s has been taken successfully in the file: %s. Preparing to compress the output using the gzip utility." % (DBS, sql_file))
                        p1 = sp.Popen("gzip -6 "+sql_file, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                        restatus1 = p1.wait()
                        if restatus1 == 0:
                            logger.info("Successfully compressed the database dump for %s. The compressed file is: %s.gz\n" % (DBS, sql_file))
                            return (sql_file+".gz")
                        else:
                            logger.error("Could not compress the database dump for %s.\n" % DBS)
                            return ""
                else:
                        logger.error("Mysqldump ended with an error for the database: %s.\n\n" % DBS)
        else:
                logger.error("The backup location: %s does not exist on the local FS, COULD NOT create backup for the database: %s.\n\n" % (BACKUP_PATH , DBS))
        return ""

def move_backup_to_hdfs(sql_file,HDFS_PATH):
        logger = logging.getLogger("default")
        logger.info("Moving the backup file %s to HDFS location: %s" % (sql_file , BACKUP_PATH))
        p2 = sp.Popen("hadoop fs -test -d "+HDFS_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
        restatus2 = p2.wait()
        flag1 = -5
        if restatus2 != 0
                p3 = sp.Popen("hadoop fs -mkdir -p "+HDFS_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                flag1 = p3.wait()
        if flag1 <=0:
                p = sp.Popen("hadoop fs -moveFromLocal "+TODAYBACKUPPATH" "+HDFS_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus = p.wait()
                if restatus == 0:
                        logger.info("Backup location %s successfully moved to HDFS location: %s\n\n" % (TODAYBACKUPPATH , HDFS_PATH))
                        return 0
                else:
                        logger.error("Backup location %s COULD NOT BE moved to HDFS location: %s\n\n" % (TODAYBACKUPPATH , HDFS_PATH))
        else:
                logger.error("The backup location: %s does not exist on HDFS. Hence the Backup could not be moved to HDFS.\n\n" % HDFS_PATH)
        return 1

def main():
        # Creating log directory if it does not exists
        if not(os.path.exists(LOG_PATH)):
                p = sp.Popen("mkdir -p "+LOG_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus4 = p.wait()

        #Setup logging
        logtime = time.strftime("%Y%m%d%H%M%S")
        logpath = LOG_PATH + '/' +"backup_mysqldb_%s_%s.log" % (logtime, os.getpid())
        defaultbaselogger = logging.getLogger("default")
        defaultbaselogger.setLevel(logging.DEBUG)
        defaultFileHandler = logging.FileHandler(logpath)
        defaultFileHandler.setLevel(logging.DEBUG)
        defaultFormatter = logging.Formatter('%(asctime)s\t%(levelname)s\t%(funcName)s\t%(process)d\t%(lineno)s\t%(message)s')
        defaultFileHandler.setFormatter(defaultFormatter)
        defaultbaselogger.addHandler(defaultFileHandler)
        logger = logging.getLogger("default")

        bashCommand = "/root/gi-hadoop-scripts/kinit_script.sh hdfs"
        os.system(bashCommand)

        #Calling the function to obtain MySQL Mysqldump
        create_db_backups(DBS,BACKUP_PATH,DB_USER,DB_USER_PASSWORD)

if __name__ == "__main__":
        main()
