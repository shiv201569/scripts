#!/usr/bin/python

#########################################################
#
# This script is for taking snapshots directly on HDFS directories
# not managed by Cloudera Manager.
#
# Written by : Shivam Agrawal
# Company : domain Ltd
# Created date: Dec 3, 2019
# Last modified: Dec 3, 2019
# Tested with : Python 2.7.15 & Python 3.5
# Script Revision: 1.0
#
#########################################################

# Import required python libraries

import sys, os, datetime, json, logging, time, re, getopt, pipes , smtplib
import subprocess as sp
from email.mime.text import MIMEText
import xml.etree.ElementTree as ET

# Adding the details which require snapshot to be enabled and Created

SNPS = '/snapshot/nameslist.txt'
LOG_PATH = '/snapshot/log'
AGE = 5
LIST_SIZE = 1
SMTP_SERVER = 'mail.domain.com'
SMTP_PORT = 25

# Getting current DateTime to create the snapshot name like "snapshot_20191203-125200".
DATETIME = time.strftime('%Y%m%d-%H%M%S')
SNPNAME = 'snapshot-' + DATETIME

# Code for checking the file if it exists or NOT

logger = logging.getLogger("default")
logger.info("Checking for snapshot client file: %s" % (SNPS))
if os.path.exists(SNPS):
    file1 = open(SNPS)
    multi = 1
    logger.info("Snapshot client file found: %s" % (SNPS))
    logger.info("Beginning the snapshot creation of each client in the file: %s" % (SNPS))
else:
    logger.error("Snapshot client file not found: %s" % (SNPS))
    multi = 0

# Starting actual snaphot creation process
def create_snapshots(SNPS):
    if multi:
        in_file = open(SNPS,"r")
        flength = len(in_file.readlines())
        in_file.close()
        p = 1
        snpfile = open(SNPS,"r")

        while p <= flength:
            snp = snpfile.readline()   # reading client name from file
            snp = snp[:-1]         # deletes extra line
            snpcmd = "hdfs dfsadmin -allowSnapshot " + snp
            os.system(snpcmd)
            logger.info("Snapshots have been enabled for %s. Preparing to take the snapshots." % (snp))
            snpenablecmd = "hdfs dfs -createSnapshot " + snp + " " + pipes.quote(SNPNAME)
            os.system(snpenablecmd)
            logger.info("Successfully taken the snapshots for %s.\n" % (snp))
            p = p + 1
        snpfile.close()

#Clear snapshots older than 5 days
def clear_old_snapshots_on_hdfs(SNPS,LIST_SIZE,AGE):
    if multi:
        in_file = open(SNPS, "r")
        flength = len(in_file.readlines())
        in_file.close()
        var = 1
        snpfile = open(SNPS,"r")

        while var <= flength:
            snp = snpfile.readline()
            snp = snp[:-1]
            logger = logging.getLogger("default")
            logger.info("Beginning the cleanup of old snaphots on %s" % (snp))
            number_of_files = AGE*LIST_SIZE
            p2 = sp.Popen("hadoop fs -test -d "+snp+"/.snapshot", stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
            restatus2 = p2.wait()
            if restatus2 == 0:
                p = sp.Popen("hadoop fs -ls "+snp+"/.snapshot" + " | grep -v Found | awk '{print $8}' | cut -d'/' -f4", stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus = p.wait()
                output = p.stdout.readlines()
                output.sort()
                output_len = len(output)
                logger.info("Obtained %s snapshot files for %s at %s" % (output_len , snp , snp+"/.snapshot"))
                difference = output_len-number_of_files
                files_not_removed = []
                flag1 = 0

                if difference > 0:
                    files_to_be_removed = output[:difference]
                    logger.info ("Found %s number of snapshot files greater than the threshold of %s files, hence removing the following oldest snapshot files from HDFS location %s" % (difference , number_of_files , snp+"/.snapshot"))
                    for file_name in files_to_be_removed:
                        p = sp.Popen("hdfs dfs -deleteSnapshot " + snp + " " + file_name.rstrip('\n'), stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                        restatus = p.wait()
                        if restatus != 0:
                            flag1 = 1
                            files_not_removed.append(file_name.rstrip('\n'))
                    if flag1==0:
                        logger.info("Successfully removed %s oldest snapshot files from HDFS location: %s\n" % (files_to_be_removed , snp))
                    else:
                        logger.error("COULD NOT remove the following old snapshot files from HDFS: %s\n" % files_not_removed)
                        return 1
                else:
                    logger.info("Number of files at %s is %s, which is less than the threshold of %s files. Thus no files to remove from HDFS.\n" % (snp , output_len , number_of_files))
            else:
                logger.info("Could not find the snapshot directory: %s in HDFS.\n" % snp)
                return 0
            var = var + 1
        snpfile.close()

def main():
        # Creating log directory if it does not exists
        if not(os.path.exists(LOG_PATH)):
            p = sp.Popen("mkdir -p "+LOG_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
            restatus4 = p.wait()

        #Setup logging
        logtime = time.strftime("%Y%m%d%H%M%S")
        logpath = LOG_PATH + '/' +"snapshot_%s_%s.log" % (logtime, os.getpid())
        defaultbaselogger = logging.getLogger("default")
        defaultbaselogger.setLevel(logging.DEBUG)
        defaultFileHandler = logging.FileHandler(logpath)
        defaultFileHandler.setLevel(logging.DEBUG)
        defaultFormatter = logging.Formatter('%(asctime)s\t%(levelname)s\t%(funcName)s\t%(process)d\t%(lineno)s\t%(message)s')
        defaultFileHandler.setFormatter(defaultFormatter)
        defaultbaselogger.addHandler(defaultFileHandler)
        logger = logging.getLogger("default")

        bashCommand = "/root/gi-hadoop-scripts/kinit_script.sh hdfs"
        os.system(bashCommand)

        #Calling the function to create snapshots
        create_snapshots(SNPS)
        clear_old_snapshots_on_hdfs(SNPS,LIST_SIZE,AGE)

        #Getting the cluster name
        tree = ET.parse('/etc/hadoop/conf/core-site.xml')
        root = tree.getroot()
        name = root[0][1].text
        name = name.strip('hdfs://-ns')

        #Mailing the result to list of receivers
        msg = sp.Popen("cat "+logpath, stdout=sp.PIPE, stderr=sp.PIPE, shell=True).communicate()[0]
        if "ERROR" in msg:

        subject = "Snapshot create alert for %s" % name
        message = MIMEText(msg)
        message['Subject'] = subject
        sender = 'snapshot@domain.CO.UK'
        receivers = ['shivam.agrawal@domain.com']

        try:
                smtpObj = smtplib.SMTP('mail.domain.com')
                smtpObj.sendmail(sender, receivers, message.as_string())
        except SMTPException:
                logger.error("Error: unable to send email")

if __name__ == "__main__":
        main()
