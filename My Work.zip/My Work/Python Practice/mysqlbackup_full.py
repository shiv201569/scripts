#!/usr/bin/python

###########################################################
#
# This python script is used for mysql databases backup
# using mysqldump and gzip utility.
#
# Written by : Shivam Agrawal
# Company : domain Ltd
# Created date: Jan 07, 2019
# Last modified: Aug 17, 2019
# Tested with : Python 2.7.15 & Python 3.5
# Script Revision: 1.0
#
##########################################################

# Import required python libraries

import sys, os, datetime, json, logging, time, re, getopt, pipes , smtplib
import subprocess as sp
from email.mime.text import MIMEText

# MySQL database details to which backup to be done. Make sure below user having enough privileges to take databases backup.
# To take multiple databases backup, create any file like /backup/dbnames.txt and put databases names one on each line and assigned to DBS variable.

DB_HOST = 'localhost'
DB_USER = 'root'
DB_USER_PASSWORD = 'Sqlr00t@devCrv'
DBS = '/backup/dbnameslist.txt'
BACKUP_PATH = '/backup/dbbackup'
LOG_PATH = '/backup/log'
HDFS_PATH = '/backup/dbbackup'
AGE = 5
LIST_SIZE = 1
SMTP_SERVER = 'mail.domain.com'
SMTP_PORT = 25

# Getting current DateTime to create the separate backup folder like "20180817-123433".
DATETIME = time.strftime('%Y%m%d-%H%M%S')
TODAYBACKUPPATH = BACKUP_PATH + '/' + DATETIME

# Checking if backup folder already exists or not. If not exists will create it.
try:
    os.stat(TODAYBACKUPPATH)
except:
    os.mkdir(TODAYBACKUPPATH)

# Code for checking if you want to take single database backup or assinged multiple backups in DBS.
logger = logging.getLogger("default")
logger.info("Checking for database names file: %s" % (DBS))
if os.path.exists(DBS):
    file1 = open(DBS)
    multi = 1
    logger.info("Database file found: %s" % (DBS))
    logger.info("Beginning the MYSQL database backup for the listed databases in: %s using %s user." % (DBS , DB_USER))
else:
    logger.error("Database file not found: %s" % (DBS))
    logger.info("Beginning the MYSQL database for: %s using %s user." % (DBS , DB_USER))
    multi = 0

# Starting actual database backup process.
def create_db_backups(DBS,BACKUP_PATH,DB_USER,DB_USER_PASSWORD):
    if multi:
        in_file = open(DBS,"r")
        flength = len(in_file.readlines())
        in_file.close()
        p = 1
        dbfile = open(DBS,"r")

        while p <= flength:
            db = dbfile.readline()   # reading database name from file
            db = db[:-1]         # deletes extra line
            dumpcmd = "mysqldump -h " + DB_HOST + " -u " + DB_USER + " -p" + DB_USER_PASSWORD + " " + db + " > " + pipes.quote(TODAYBACKUPPATH) + "/" + db + ".sql"
            os.system(dumpcmd)
            logger.info("MYSQL database backup for %s has been taken successfully. Preparing to compress the output using the gzip utility." % (db))
            gzipcmd = "gzip " + pipes.quote(TODAYBACKUPPATH) + "/" + db + ".sql"
            os.system(gzipcmd)
            logger.info("Successfully compressed the database dump for %s.\n" % (db))
            p = p + 1
        dbfile.close()
    else:
        db = DBS
        dumpcmd = "mysqldump -h " + DB_HOST + " -u " + DB_USER + " -p" + DB_USER_PASSWORD + " " + db + " > " + pipes.quote(TODAYBACKUPPATH) + "/" + db + ".sql"
        os.system(dumpcmd)
        logger.info("MYSQL database backup for %s has been taken successfully. Preparing to compress the output using the gzip utility." % (db))
        gzipcmd = "gzip " + pipes.quote(TODAYBACKUPPATH) + "/" + db + ".sql"
        os.system(gzipcmd)
        logger.info("Successfully compressed the database dump for %s.\n\n" % (db))

def move_backup_to_hdfs(TODAYBACKUPPATH,HDFS_PATH):
        logger = logging.getLogger("default")
        logger.info("Moving the backup location %s to HDFS location: %s" % (TODAYBACKUPPATH , BACKUP_PATH))
        p2 = sp.Popen("hadoop fs -test -d "+HDFS_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
        restatus2 = p2.wait()
        flag1 = -5
        if restatus2 != 0:
                p3 = sp.Popen("hadoop fs -mkdir -p "+HDFS_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                flag1 = p3.wait()
        if flag1 <=0:
                p = sp.Popen("hadoop fs -moveFromLocal "+TODAYBACKUPPATH+" "+HDFS_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus = p.wait()
                if restatus == 0:
                        logger.info("Backup location %s successfully moved to HDFS location: %s\n\n" % (TODAYBACKUPPATH , HDFS_PATH))
                        return 0
                else:
                        logger.error("Backup location %s COULD NOT BE moved to HDFS location: %s\n\n" % (TODAYBACKUPPATH , HDFS_PATH))
        else:
                logger.error("The backup location: %s does not exist on HDFS. Hence the Backup could not be moved to HDFS.\n\n" % HDFS_PATH)
        return 1

def clear_old_backups_on_hdfs(DBS,LIST_SIZE,BACKUP_PATH,AGE):
        logger = logging.getLogger("default")
        logger.info("Beginning the cleanup of old backup location on HDFS: %s" % (DBS))
        number_of_files = AGE*LIST_SIZE
        p2 = sp.Popen("hadoop fs -test -d "+BACKUP_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
        restatus2 = p2.wait()
        if restatus2 == 0:
                p = sp.Popen("hadoop fs -ls "+BACKUP_PATH+" | grep -v Found | awk '{print $8}'", stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus = p.wait()
                output = p.stdout.readlines()
                output.sort()
                output_len = len(output)
                logger.info("Obtained %s backup files for %s at: %s" % (output_len , DBS , BACKUP_PATH))
                difference = output_len-number_of_files
                files_not_removed = []
                flag1 = 0

                if difference > 0:
                        files_to_be_removed = output[:difference]
                        logger.info ("Found %s number of files greater than the threshold of %s files, hence removing the following oldest files from HDFS location: %s" % (difference , number_of_files , files_to_be_removed))
                        for file_name in files_to_be_removed:
                                p = sp.Popen("hadoop fs -rmr "+file_name.rstrip('\n'), stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                                restatus = p.wait()
                                if restatus != 0:
                                        flag1 = 1
                                        files_not_removed.append(file_name.rstrip('\n'))
                        if flag1==0:
                                logger.info("Successfully removed %s oldest files from HDFS location: %s\n" % (files_to_be_removed , BACKUP_PATH))
                        else:
                                logger.error("COULD NOT remove the following old files from HDFS: %s\n" % files_not_removed)
                                return 1
                else:
                        logger.info("Number of files at %s is %s, which is less than the threshold of %s files. Thus no files to remove from HDFS.\n" % (BACKUP_PATH , output_len , number_of_files))
        else:
                logger.info("Could not find the backup directory: %s in HDFS.\n" % BACKUP_PATH)
        return 0


def main():
        # Creating log directory if it does not exists
        if not(os.path.exists(LOG_PATH)):
                p = sp.Popen("mkdir -p "+LOG_PATH, stdout=sp.PIPE, stderr=sp.PIPE, shell=True)
                restatus4 = p.wait()

        #Setup logging
        logtime = time.strftime("%Y%m%d%H%M%S")
        logpath = LOG_PATH + '/' +"backup_mysqldb_%s_%s.log" % (logtime, os.getpid())
        defaultbaselogger = logging.getLogger("default")
        defaultbaselogger.setLevel(logging.DEBUG)
        defaultFileHandler = logging.FileHandler(logpath)
        defaultFileHandler.setLevel(logging.DEBUG)
        defaultFormatter = logging.Formatter('%(asctime)s\t%(levelname)s\t%(funcName)s\t%(process)d\t%(lineno)s\t%(message)s')
        defaultFileHandler.setFormatter(defaultFormatter)
        defaultbaselogger.addHandler(defaultFileHandler)
        logger = logging.getLogger("default")

        bashCommand = "/root/gi-hadoop-scripts/kinit_script.sh hdfs"
        os.system(bashCommand)

        #Calling the function to obtain MySQL Mysqldump
        create_db_backups(DBS,BACKUP_PATH,DB_USER,DB_USER_PASSWORD)
        move_backup_to_hdfs(TODAYBACKUPPATH,HDFS_PATH)
        clear_old_backups_on_hdfs(DBS,LIST_SIZE,BACKUP_PATH,AGE)

        #Mailing the result to list of receivers
        msg = sp.Popen("cat "+logpath, stdout=sp.PIPE, stderr=sp.PIPE, shell=True).communicate()[0]
        subject = "MySQL dump alert on CRV Cluster"
        message = MIMEText(msg)
        message['Subject'] = subject
        sender = 'mysqldump@DHCRV.EXT'
        receivers = ['shivam.agrawal@domain.com']

        try:
                smtpObj = smtplib.SMTP('mail.domain.com')
                smtpObj.sendmail(sender, receivers, message.as_string())
        except SMTPException:
                logger.error("Error: unable to send email")

if __name__ == "__main__":
        main()
