#!/usr/bin/env python
# coding: utf-8

# In[1]:


from yarn_api_client.history_server import HistoryServer
from yarn_api_client.resource_manager import ResourceManager
from requests_kerberos import HTTPKerberosAuth
import pprint, requests
from datetime import datetime, timedelta
from lxml import html
import re
import os
import re

hours_history = 18
queue_prefix = 'root.dm'
job_prefix = ''
started_time_begin = None
socket_timeout = 15


# In[2]:


import re

def append_long_sockets(log, long_sockets, application_id, machine, job_name, f, user, job_started_time):
    READY=1
    ACCEPTED=2
    last_port = None
    last_time = None
    last_log_type = ACCEPTED
    for line in log.split('\n'):
        match = re.match( "^([0-9]{1,2}\/[0-9]{2}\/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}) TRACE python.PythonServer: (about to accept connections on port|accepted connection on port) ([0-9]{1,5})", line)
        if match:
            date = datetime.strptime(match[1], '%y/%m/%d %H:%M:%S')
            log_type = READY if match[2] == "about to accept connections on port" else ACCEPTED
            port     = match[3]
            if last_log_type == log_type:
                print(f"WARNING: Woah nelly. was not expecting {log_type} again so soon")
                break
            elif last_log_type == READY and port != last_port:
                print("OOOOh boy, these are not the ports i was looking for")
                break
            elif last_log_type == READY:
                duration = date - last_date
                duration_s = duration.total_seconds()
                if duration_s >= socket_timeout:
                    long_sockets.append((application_id, user, machine, job_started_time, last_date, date, port, job_name, duration_s))
                    f.write(f"{application_id} {user} {machine} {started_time} {last_date} {date} {port} {job_name} {duration_s}\n")
                    f.flush()
            last_date = date
            last_port = port
            last_log_type = log_type


# In[3]:


if not started_time_begin:
    started_time_begin = datetime.now() - timedelta(hours=hours_history)
else:
    started_time_begin = current_run
start_timestamp = int(started_time_begin.timestamp()) *1000
current_run = datetime.now()
current_run_timestamp = int(current_run.timestamp())


# In[4]:


rmEndpoints = ['https://gbwatbd2r01s03.domain.co.uk:8090']
rm = ResourceManager(rmEndpoints, auth=HTTPKerberosAuth())

appStates=["FINISHED", "FAILED"]

response = rm.cluster_applications(states=appStates, started_time_begin=start_timestamp)


# In[5]:


apps = response.data['apps']['app']
apps = [ x for x in apps if (x["queue"].startswith(queue_prefix) and x['name'].startswith(job_prefix) and "amContainerLogs" in x)]
print(f"Number of Apps: {len(apps)}")


# In[ ]:


long_sockets = []
f = open(f"dh_socket_test.log", 'a')
for app in apps:
    am_node = app['amHostHttpAddress']
    job_name = app["name"]
    started_time = datetime.fromtimestamp(int(app['startedTime']/1000))
    application_id =  app['id']
    user = app["user"]
    logs_url = app['amContainerLogs'] + "/stderr/?start=0"
    r = requests.get(logs_url, auth=HTTPKerberosAuth())
    tree = html.fromstring(r.text)
    try:
        stderr = tree.xpath("/html/body/table/tbody/tr/td[@class='content']/pre[1]")[0].text
    except IndexError:
        continue
    if stderr:
        #print(am_node)
        #print(started_time)
        f.write(application_id+"\n")
        f.flush()
        #print(logs_url)
        append_long_sockets(stderr, long_sockets, application_id, am_node, job_name, f, user, started_time)


# In[ ]:


jobs = set([])
sorted_failures = sorted(long_sockets, key=lambda x: x[-1], reverse=True)
_ =open(f"dh_sorted_failures_{current_run_timestamp}.log",'w').write(f"{sorted_failures}")
for i in sorted_failures:
    if i[8] > 1:
        jobs.update(set([(i[0],i[1],i[2])]))
    print(i)

_ = open(f"dh_identified_jobs_{current_run_timestamp}.log", 'w').write(f"{jobs}")


# In[ ]:


import pprint

pprint.pprint(jobs)


# In[ ]:




