print("Unravel: Initializing tagging script")

def get_tags(app_obj):
    if app_obj is None:
        return None

    app_type = app_obj.getAppType()
    app_id = app_obj.getAppId()
    project_name = None
    dept_name = None
    wf_name = None
    wf_utc = None
    print ("Unravel: Getting tags for " + app_id + " " + app_type)

    tags = {}

    if app_type == 'mr':
        project_name = app_obj.getAppConf("project.name")
        dept_name = app_obj.getAppConf("dept.name")
        wf_name = app_obj.getAppConf("workflow.name")
        wf_utc = app_obj.getAppConf("workflow.utctimestamp")
    elif app_type == 'spark':
        project_name = app_obj.getAppConf("spark.project.name")
        dept_name = app_obj.getAppConf("spark.dept.name")
        wf_name = app_obj.getAppConf("spark.workflow.name")
        wf_utc = app_obj.getAppConf("spark.workflow.utctimestamp")

    if project_name and dept_name:
        tags['project'] = project_name
        tags['dept'] = dept_name

    if wf_name and wf_utc:
        if app_type == 'mr':
            tags['unravel.workflow.name'] = wf_name
            tags['unravel.workflow.utctimestamp'] = wf_utc
        elif app_type == 'spark':
            tags['spark.unravel.workflow.name'] = wf_name
            tags['spark.unravel.workflow.utctimestamp'] = wf_utc

    print ("Unravel: tags for " + app_id + " " + app_type + " " + str(tags))

    return tags

