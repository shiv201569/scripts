#!/bin/bash
#set -o xtrace
export PATH=$PATH:/dhcommon/bin
source "`which /dhcommon/bin/log4dh_bash`" || { echo "log4dh_bash not found. Ensure this script is on users PATH." >&2; exit 1; }

setup_dbs_help() {
  cat >&2 <<EOF
NAME
    setup_dbs_ - Setup folders and databases for the Data Lake.

SYNOPSIS
    setup_dbs OPTIONS
        --unix-root-dir UNIX_ROOT\\
        --hdfs-root-dir HDFS_ROOT\\
        --client-short-name CLIENT_SHORT_NAME\\
        --dm-group DM_GRP\\
        --an-group AN_GRP\\
        --os-group OS_DM_GRP\\
        --super-group SUPER_GRP\\
        --impala-server IMPALA_HA_PROXY\\
        --hdfs-name-service HDFS_NAME_SERVICE\\
        --has-discovery "Y"|""\\
        --help

DESCRIPTION

    Setup folders and databases for the Data Lake.

Options

  -r, --unix-root-dir UNIX_BASE
      The root folder for HDFS folders and databases.

  -f, --hdfs-root-dir ROOTDIR
      The root folder for HDFS folders and databases.

  -c, --client-short-name CLIENT_SHORT
      Short name for the client, preferablly 3 characters.

  -d, --dm-group DM_GROUP
                Name of the Unix group for Data Manager.

  -n, --an-group AN_GROUP
      Analyst Unix group name.

  -o, --os-group OS_DM_GROUP
                Name of the Unix group for Data Manager.

  -s, --super-group SUPER_GROUP
                Super group.

  -i, --impala-server IMPALA_SERVER
                Imapla HA Proxy.

  -p, --hdfs-name-service HDFS_NAME_SERVICE
                HDFS named service.

  -a, --has-discovery
                Y if market requires a discovery database otherwise N

  -h, --help
      Display this usage message

Examples:

Create Unix and HDFS Directories for setting up data lake.

   ./setup_hadoop_datalake.sh \\
        --unix-root-dir "/office_depot"\\
        --hdfs-root-dir "/office_depot"\\
        --client-short-name "od"\\
        --dm-group "UNIX_TESCOUK_DM"\\
        --an-group "UNIX_TESCOUK_AN"\\
        --os-group "UNIX_TESCOUK_OS_DM"\\
        --super-group "UNIX_TESCOUK_SUPER"\\
        --hive-server "us-lou-svr-2004"\\
        --hdfs-name-service "us-lou-svb-2010.dunnhumby.co.uk"\\
        --has-discovery "Y"

Report bugs to <GlobalDataPlatformsTeam@dunnhumby.com>

EOF
}

checkStatus () {
        if [[ $? != 0 ]]; then
                log4dh_error "Last command FAILED."
                aim_loge config=${DEFAULT_AIM_INI_PATH} CMDFILE=${CMDFILE}
                exit 1
#       else
#               log4dh_info "SUCCEED in $1"
        fi
}


# Parse command line options
while true; do
  [[ $# == 0 ]] && break
  case "$1" in
    -h|--help) setup_dbs_help
               exit 0 ;;
    -r|--unix-root-dir) shift
                   UNIX_ROOTDIR="${1}"
                   shift
                   ;;
    -f|--hdfs-root-dir) shift
                   ROOTDIR="${1}"
                   shift
                   ;;
    -c|--client-short-name) shift
           CLIENT_SHORT="${1}"
                   shift
           ;;
    -d|--dm-group) shift
           DM_GROUP="${1}"
                   shift
           ;;
    -n|--an-group) shift
           AN_GROUP="${1}"
                   shift
           ;;
    -o|--os-group) shift
           OS_DM_GROUP="${1}"
                   shift
           ;;
    -s|--super-group) shift
           SUPER_GROUP="${1}"
                   shift
           ;;
    -i|--hive-server) shift
           HIVE_SERVER="${1}"
                   shift
           ;;
    -p|--hdfs-name-service) shift
           HDFS_NAME_SERVICE="${1}"
                   shift
           ;;
    -a|--has-discovery) shift
           HAS_DISCOVERY="${1}"
                   shift
           ;;
    *)     log4dh_error "Unknown option: \"$1\""
            exit 1
            ;;
  esac
done

log4dh_info "UNIX_ROOTDIR: ${UNIX_ROOTDIR}"
log4dh_info "ROOTDIR: ${ROOTDIR}"
log4dh_info "CLIENT_SHORT: ${CLIENT_SHORT}"
log4dh_info "DM_GROUP: ${DM_GROUP}"
log4dh_info "AN_GROUP: ${AN_GROUP}"
log4dh_info "OS_DM_GROUP: ${OS_DM_GROUP}"
log4dh_info "SUPER_GROUP: ${SUPER_GROUP}"
log4dh_info "HIVE_SERVER: ${HIVE_SERVER}"
log4dh_info "HDFS_NAME_SERVICE: ${HDFS_NAME_SERVICE}"
log4dh_info "HAS_DISCOVERY: ${HAS_DISCOVERY}"

#################################### Verify mandatory parameters given #########################################

log4dh_info "Verify that the mandatory parameters are provided or not."
[[ "$UNIX_ROOTDIR" == "" ]]             && { log4dh_error "The -r|--unix-root-dir option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }
[[ "$ROOTDIR" == "" ]]                  && { log4dh_error "The -f|--hdfs-root-dir option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }
[[ "$CLIENT_SHORT" == "" ]]             && { log4dh_error "The -c|--client-short-name option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }
[[ "$DM_GROUP" == "" ]]                 && { log4dh_error "The -d|--dm-group option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }
[[ "$AN_GROUP" == "" ]]                 && { log4dh_error "The -n|--an-group option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }
[[ "$SUPER_GROUP" == "" ]]              && { log4dh_error "The -s|--super-group option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }
[[ "$HIVE_SERVER" == "" ]]            && { log4dh_error "The -i|--hive-server option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }
[[ "$HDFS_NAME_SERVICE" == "" ]]    && { log4dh_error "The -p|--hdfs-name-service option must have a value" ; eval "${cleanup_cmds}" ; exit 1; }

log4dh_info "All mandatory parameters are provided, proceeding to setup..."

CLIENT_SHORT=$(echo $CLIENT_SHORT | tr '[:upper:]' '[:lower:]')

# Parent folder /<market>/APP_NAME would be used to keep all datalake specific files.
APP_NAME="datalake"
MOSOQ_GROUP="UNIX_MOSOQ_SUPER"

log4dh_info "Checking that all neccessary Unix Groups already exists, if any is missing the script will exit without performing any change."
log4dh_info 'COMMAND: getent group ${DM_GROUP}'
getent group ${DM_GROUP}
checkStatus

log4dh_info 'COMMAND: getent group ${AN_GROUP}'
getent group ${AN_GROUP}
checkStatus

log4dh_info 'COMMAND: getent group ${SUPER_GROUP}'
getent group ${SUPER_GROUP}
checkStatus

if [[ "$OS_DM_GROUP" != "" ]]; then
        log4dh_info 'COMMAND: getent group ${OS_DM_GROUP}'
        getent group ${OS_DM_GROUP}
        checkStatus
fi

if [ ! -d "/$UNIX_ROOTDIR" ]; then
   log4dh_error "$UNIX_ROOTDIR does not exists, please get the storage mounted (base folder created) on the server and try again."
   exit 1
fi

log4dh_info "======== STARTING PROCESSING FOR ENVIRONMENT CREATION ==========="
log4dh_info 'Creating the Unix Directory structure'

log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}"
mkdir -p /${UNIX_ROOTDIR}
checkStatus

log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}"
mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}
checkStatus

#log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/oozie"
#mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/oozie
#checkStatus

log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin"
mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin
checkStatus

log4dh_info "COMMAND: cp /root/gi-hadoop-scripts/omni_qa_columns_template /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin/"
cp /root/gi-hadoop-scripts/omni_qa_columns_template /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin/
checkStatus

log4dh_info "COMMAND: cp /root/gi-hadoop-scripts/omni_escape_newlines /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin/"
cp /root/gi-hadoop-scripts/omni_escape_newlines /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin/
checkStatus

log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/inbound"
mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/inbound
checkStatus


log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing/archive"
mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing/archive
checkStatus

log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing/badfiles"
mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing/badfiles
checkStatus

log4dh_info "COMMAND: chown -R root:${DM_GROUP} /${ROOTDIR}/${APP_NAME}"
chown -R root:${DM_GROUP} /${ROOTDIR}/${APP_NAME}
checkStatus

log4dh_info "COMMAND: chmod -R 2755 /${UNIX_ROOTDIR}"
chmod 2755 /${UNIX_ROOTDIR}
checkStatus

log4dh_info "COMMAND: chmod -R 2775 /${UNIX_ROOTDIR}/${APP_NAME}"
chmod 2775 /${UNIX_ROOTDIR}/${APP_NAME}
checkStatus

log4dh_info "COMMAND: chmod -R 2770 /${UNIX_ROOTDIR}/${APP_NAME}/inbound"
chmod -R 2770 /${UNIX_ROOTDIR}/${APP_NAME}/inbound
checkStatus

log4dh_info "COMMAND: chmod -R 2770 /${UNIX_ROOTDIR}/${APP_NAME}/processing"
chmod -R 2770 /${UNIX_ROOTDIR}/${APP_NAME}/processing
checkStatus

log4dh_info "COMMAND: chmod -R  2775 /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts"
chmod -R 2775 /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts
checkStatus

log4dh_info "COMMAND: chmod  2777 /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin"
chmod 2777 /${UNIX_ROOTDIR}/${APP_NAME}/app_artefacts/bin
checkStatus

# ACLs are not enabled on the zfs mounts, so commented following commands for now.
#log4dh_info "COMMAND: setfacl -m g:${MOSOQ_GROUP}:r-x /${ROOTDIR}"
#setfacl -m g:${MOSOQ_GROUP}:r-x /${ROOTDIR}
#checkStatus

#log4dh_info "COMMAND: setfacl -m g:${MOSOQ_GROUP}:r-x /${ROOTDIR}/${APP_NAME}"
#setfacl -R -m g:${MOSOQ_GROUP}:rwx /${ROOTDIR}/${APP_NAME}
#checkStatus

if [[ "$OS_DM_GROUP" != "" ]]; then
        log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/inbound_onshore"
        mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/inbound_onshore
        checkStatus

        log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore/archive"
        mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore/archive
        checkStatus

        log4dh_info "COMMAND: mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore/badfiles"
        mkdir -p /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore/badfiles
        checkStatus

        log4dh_info "COMMAND: chown -R root:${OS_DM_GROUP} /${UNIX_ROOTDIR}/${APP_NAME}/inbound_onshore"
        chown -R root:${OS_DM_GROUP} /${UNIX_ROOTDIR}/${APP_NAME}/inbound_onshore
        checkStatus

        log4dh_info "COMMAND: /${UNIX_ROOTDIR}/${APP_NAME}/inbound_onshore"
        chmod -R 770 /${UNIX_ROOTDIR}/${APP_NAME}/inbound_onshore
        checkStatus

        log4dh_info "COMMAND: chown -R root:${OS_DM_GROUP} /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore"
        chown -R root:${OS_DM_GROUP} /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore
        checkStatus

        log4dh_info "COMMAND: chmod -R 770 /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore"
        chmod -R 770 /${UNIX_ROOTDIR}/${APP_NAME}/processing_onshore
        checkStatus
fi

log4dh_info "Unix Directory structure created."

log4dh_info "Kinit as HDFS to create the Directory structure"
log4dh_info "COMMAND: /root/gi-hadoop-scripts/kinit_script.sh hdfs"

/root/gi-hadoop-scripts/kinit_script.sh hdfs
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}"
hdfs dfs -mkdir -p /${ROOTDIR}
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod 0550 /${ROOTDIR}"
hdfs dfs -chmod 0550 /${ROOTDIR}
checkStatus

#Make root of solution readable by DM & AN groups

log4dh_info "COMMAND: hdfs dfs -setfacl -m user::r-x,default:user::rwx,group::r-x,default:group::rwx,group:hive:r-x,default:group:hive:rwx,group:${DM_GROUP}:r-x,default:group:${DM_GROUP}:rwx,group:${AN_GROUP}:r-x,default:group:${AN_GROUP}:r-x,group:${MOSOQ_GROUP}:r-x,default:group:${MOSOQ_GROUP}:rwx /${ROOTDIR}"

hdfs dfs -setfacl -m user::r-x,default:user::rwx,,group::r-x,default:group::rwx,group:hive:r-x,default:group:hive:rwx,group:${DM_GROUP}:r-x,default:group:${DM_GROUP}:rwx,group:${AN_GROUP}:r-x,default:group:${AN_GROUP}:r-x,group:${MOSOQ_GROUP}:r-x,default:group:${MOSOQ_GROUP}:rwx /${ROOTDIR}

checkStatus "setting acls of root directory."

if [[ "$OS_DM_GROUP" != "" ]]; then
        log4dh_info "COMMAND: hdfs dfs -setfacl -m group:${OS_DM_GROUP}:r-x,default:group:${OS_DM_GROUP}:r-x /${ROOTDIR}"
        hdfs dfs -setfacl -m group:${OS_DM_GROUP}:r-x,default:group:${OS_DM_GROUP}:rwx /${ROOTDIR}
        checkStatus "setting acls."
fi

log4dh_info "Create OFFShore and ONShore areas and setting permissions accordingly:"

######### Create databases directories ##########
SUFFIX="inbound"

log4dh_info "Create databases directories & setting permissions for inbound"

DIR_OFFSHORE=/${ROOTDIR}/${SUFFIX}
DIR_DISCOVERY=/${ROOTDIR}/discovery

log4dh_info "COMMAND: hdfs dfs -mkdir -p ${DIR_OFFSHORE} ${DIR_OFFSHORE}_tmp"
hdfs dfs -mkdir -p ${DIR_OFFSHORE} ${DIR_OFFSHORE}_tmp /${ROOTDIR}/files_wo_dis
checkStatus "creating database dir."

log4dh_info "Creating additional databases(adm,analysis,etl,tmp,segmentations,lib,scripts,specification,staging)"

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/adm"
hdfs dfs -mkdir -p /${ROOTDIR}/adm
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/analysis"
hdfs dfs -mkdir -p /${ROOTDIR}/analysis
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/etl"
hdfs dfs -mkdir -p /${ROOTDIR}/etl
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/tmp"
hdfs dfs -mkdir -p /${ROOTDIR}/tmp
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/segmentations"
hdfs dfs -mkdir -p /${ROOTDIR}/segmentations
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/lib"
hdfs dfs -mkdir -p /${ROOTDIR}/lib
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/lib/{jars,python}"
hdfs dfs -mkdir -p /${ROOTDIR}/lib/{jars,python}
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/scripts"
hdfs dfs -mkdir -p /${ROOTDIR}/scripts
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/specification"
hdfs dfs -mkdir -p /${ROOTDIR}/specification
checkStatus

log4dh_info "COMMAND: hdfs dfs -mkdir -p /${ROOTDIR}/staging"
hdfs dfs -mkdir -p /${ROOTDIR}/staging
checkStatus

#log4dh_info "COMMAND: hdfs dfs -setfacl -m default:group:${DM_GROUP}:rwx,group:${DM_GROUP}:rwx,default:group:${MOSOQ_GROUP}:rwx,group:${MOSOQ_GROUP}:rwx ${DIR_OFFSHORE}"
#hdfs dfs -setfacl -m default:user::rwx,default:group::rwx,default:group:${DM_GROUP}:rwx,group:${AN_GROUP}:r-x,default:group:${MOSOQ_GROUP}:rwx,group:${MOSOQ_GROUP}:rwx ${DIR_OFFSHORE}
#checkStatus

#log4dh_info "COMMAND: hdfs dfs -setfacl -m default:group:${DM_GROUP}:rwx,group:${DM_GROUP}:rwx,default:group:${MOSOQ_GROUP}:rwx,group:${MOSOQ_GROUP}:rwx ${DIR_OFFSHORE}_tmp"
#hdfs dfs -setfacl -m default:user::rwx,default:group::rwx,default:group:${DM_GROUP}:rwx,group:${DM_GROUP}:rwx,default:group:${MOSOQ_GROUP}:rwx,group:${MOSOQ_GROUP}:rwx ${DIR_OFFSHORE}_tmp
#checkStatus

#log4dh_info "COMMAND: hdfs dfs -setfacl -m default:group:${DM_GROUP}:rwx,group:${DM_GROUP}:rwx,default:group:${MOSOQ_GROUP}:rwx,group:${MOSOQ_GROUP}:rwx ${DIR_OFFSHORE}"
#hdfs dfs -setfacl -m default:user::rwx,default:group::rwx,default:group:${DM_GROUP}:rwx,group:${DM_GROUP}:rwx,default:group:${MOSOQ_GROUP}:rwx,group:${MOSOQ_GROUP}:rwx /${ROOTDIR}/files_wo_dis
#checkStatus

####### Finally make everything own by Hive user. #####

log4dh_info "Finally make root directory owned by Hive user. DON'T do this recursively to ensure there is any existing data, it won't get impacted."


log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}"
hdfs dfs -chown hive:hive /${ROOTDIR}
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${DIR_OFFSHORE}"
hdfs dfs -chown -R hive:hive ${DIR_OFFSHORE}
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/files_wo_dis"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/files_wo_dis
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/adm"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/adm
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/analysis"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/analysis
hdfs dfs -setfacl -m group:UNIX_SHOPRITE_AN:rwx,default:group:UNIX_SHOPRITE_AN:rwx /${ROOTDIR}/analysis
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/etl"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/etl
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/tmp"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/tmp
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/segmentations"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/segmentations
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown -R hive:hive /${ROOTDIR}/lib"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/lib
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/scripts"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/scripts
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/specification"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/specification
checkStatus

log4dh_info "COMMAND: hdfs dfs -chown hive:hive /${ROOTDIR}/staging"
hdfs dfs -chown -R hive:hive /${ROOTDIR}/staging
checkStatus

log4dh_info "Create folders for inbound_tmp database and set permissions"
log4dh_info "COMMAND: hdfs dfs -chown hive:hive ${DIR_OFFSHORE}_tmp"
hdfs dfs -chown -R hive:hive ${DIR_OFFSHORE}_tmp
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 ${DIR_OFFSHORE}"
hdfs dfs -chmod -R 770 ${DIR_OFFSHORE}
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 ${DIR_OFFSHORE}_tmp"
hdfs dfs -chmod -R 770 ${DIR_OFFSHORE}_tmp
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/files_wo_dis"
hdfs dfs -chmod -R 770 /${ROOTDIR}/files_wo_dis
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/adm"
hdfs dfs -chmod -R 770 /${ROOTDIR}/adm
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/analysis"
hdfs dfs -chmod -R 770 /${ROOTDIR}/analysis
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/etl"
hdfs dfs -chmod -R 770 /${ROOTDIR}/etl
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/tmp"
hdfs dfs -chmod -R 770 /${ROOTDIR}/tmp
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/segmentations"
hdfs dfs -chmod -R 770 /${ROOTDIR}/segmentations
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/lib"
hdfs dfs -chmod -R 770 /${ROOTDIR}/lib
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/scripts"
hdfs dfs -chmod -R 770 /${ROOTDIR}/scripts
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/specification"
hdfs dfs -chmod -R 770 /${ROOTDIR}/specification
checkStatus

log4dh_info "COMMAND: hdfs dfs -chmod -R 770 /${ROOTDIR}/staging"
hdfs dfs -chmod -R 770 /${ROOTDIR}/staging
checkStatus

if [[ "$HAS_DISCOVERY" != "" ]]; then
        log4dh_info "Create folders for discovery database as user selected that option."

        log4dh_info "COMMAND: hdfs dfs -mkdir -p ${DIR_DISCOVERY}"
        hdfs dfs -mkdir -p ${DIR_DISCOVERY}
        checkStatus

        log4dh_info "COMMAND: hdfs dfs -chown hive:hive ${DIR_DISCOVERY}"
        hdfs dfs -chown -R hive:hive ${DIR_DISCOVERY}
        checkStatus

        log4dh_info "COMMAND: hdfs dfs -chmod -R 770 ${DIR_DISCOVERY}"
        hdfs dfs -chmod -R 770 ${DIR_DISCOVERY}
        checkStatus
fi

if [[ "$OS_DM_GROUP" != "" ]]; then
        DIR_ONSHORE=/${ROOTDIR}/inbound_onshore
        log4dh_info "COMMAND: hdfs dfs -mkdir -p ${DIR_ONSHORE} ${DIR_ONSHORE}_tmp"
        hdfs dfs -mkdir -p ${DIR_ONSHORE} ${DIR_ONSHORE}_tmp
        checkStatus "creating onshore dir."

        log4dh_info "Removing access to ONShore folder from other groups."
        log4dh_info "COMMAND: hdfs dfs -setfacl -x group:${DM_GROUP},default:group:${DM_GROUP},group:${AN_GROUP},default:group:${AN_GROUP},default:group:${MOSOQ_GROUP},group:${MOSOQ_GROUP} ${DIR_ONSHORE}"
        hdfs dfs -setfacl -x group:${DM_GROUP},default:group:${DM_GROUP},group:${AN_GROUP},default:group:${AN_GROUP},default:group:${MOSOQ_GROUP},group:${MOSOQ_GROUP} ${DIR_ONSHORE}
        checkStatus

        log4dh_info "COMMAND: hdfs dfs -setfacl -m default:group:${OS_DM_GROUP}:rwx,group:${OS_DM_GROUP}:rwx ${DIR_ONSHORE}"
        hdfs dfs -setfacl -m default:group:${OS_DM_GROUP}:rwx,group:${OS_DM_GROUP}:rwx ${DIR_ONSHORE}
        checkStatus

        log4dh_info "COMMAND: hdfs dfs -setfacl -x group:${DM_GROUP},default:group:${DM_GROUP},group:${AN_GROUP},default:group:${AN_GROUP},default:group:${MOSOQ_GROUP},group:${MOSOQ_GROUP} ${DIR_ONSHORE}_tmp"
        hdfs dfs -setfacl -x group:${DM_GROUP},default:group:${DM_GROUP},group:${AN_GROUP},default:group:${AN_GROUP},default:group:${MOSOQ_GROUP},group:${MOSOQ_GROUP} ${DIR_ONSHORE}_tmp
        checkStatus "setting acls."

        log4dh_info "COMMAND: hdfs dfs -setfacl -m default:group:${OS_DM_GROUP}:rwx,group:${OS_DM_GROUP}:rwx ${DIR_ONSHORE}_tmp"
        hdfs dfs -setfacl -m default:group:${OS_DM_GROUP}:rwx,group:${OS_DM_GROUP}:rwx ${DIR_ONSHORE}_tmp
        checkStatus "setting acls."

                ####### Finally make everything own by Hive user for onshore. #####
                log4dh_info "COMMAND: hdfs dfs -chmod -R 770 ${DIR_ONSHORE}"
                hdfs dfs -chmod -R 770 ${DIR_ONSHORE}
                checkStatus

                log4dh_info "COMMAND: hdfs dfs -chmod -R 770 ${DIR_ONSHORE}_tmp"
                hdfs dfs -chmod -R 770 ${DIR_ONSHORE}_tmp
                checkStatus

                log4dh_info "COMMAND: hdfs dfs -chown hive:hive ${DIR_ONSHORE}"
                hdfs dfs -chown -R hive:hive ${DIR_ONSHORE}
                checkStatus

                log4dh_info "COMMAND: hdfs dfs -chown hive:hive ${DIR_ONSHORE}_tmp"
                hdfs dfs -chown -R hive:hive ${DIR_ONSHORE}_tmp
                checkStatus

fi

log4dh_info "HDFS Related setup completed, Connecting to Hive with Hive user and creating databases:"

log4dh_info "COMMAND: /root/gi-hadoop-scripts/kinit_script.sh hive."
/root/gi-hadoop-scripts/kinit_script.sh hive
checkStatus

####### Creating Sentry Roles & Databases #####

URI_BASE=hdfs://${HDFS_NAME_SERVICE}/${ROOTDIR}
URI_BASE2=hdfs:///${ROOTDIR}


( /usr/bin/beeline -u "jdbc:hive2://${HIVE_SERVER}:10000/default;principal=hive/${HIVE_SERVER}.dunnhumby.co.uk@DUNNHUMBY.CO.UK" <<EOF
   create role ${CLIENT_SHORT}_dm;
   create role ${CLIENT_SHORT}_an;
   create role ${CLIENT_SHORT}_super;
   GRANT ROLE ${CLIENT_SHORT}_dm TO GROUP ${DM_GROUP};
   GRANT ROLE ${CLIENT_SHORT}_dm TO GROUP ${MOSOQ_GROUP};
   GRANT ROLE ${CLIENT_SHORT}_an TO GROUP ${AN_GROUP};
   GRANT ROLE ${CLIENT_SHORT}_super TO GROUP ${SUPER_GROUP};

   create database if not exists ${CLIENT_SHORT}_${SUFFIX} location 'hdfs://${HDFS_NAME_SERVICE}${DIR_OFFSHORE}';
   grant all on database ${CLIENT_SHORT}_${SUFFIX} to ROLE ${CLIENT_SHORT}_dm;
   grant select on database ${CLIENT_SHORT}_${SUFFIX} to ROLE ${CLIENT_SHORT}_an;

   create database if not exists ${CLIENT_SHORT}_${SUFFIX}_tmp location 'hdfs://${HDFS_NAME_SERVICE}${DIR_OFFSHORE}_tmp';
   grant all on database ${CLIENT_SHORT}_${SUFFIX}_tmp to ROLE ${CLIENT_SHORT}_dm;
   grant select on database ${CLIENT_SHORT}_${SUFFIX}_tmp to ROLE ${CLIENT_SHORT}_an;

   create database if not exists ${CLIENT_SHORT}_adm location 'hdfs://${HDFS_NAME_SERVICE}/${ROOTDIR}/adm';
   grant all on database ${CLIENT_SHORT}_adm to ROLE ${CLIENT_SHORT}_dm;
   grant select on database ${CLIENT_SHORT}_adm to ROLE ${CLIENT_SHORT}_an;

   create database if not exists ${CLIENT_SHORT}_analysis location 'hdfs://${HDFS_NAME_SERVICE}/${ROOTDIR}/analysis';
   grant all on database ${CLIENT_SHORT}_analysis to ROLE ${CLIENT_SHORT}_dm;
   grant all on database ${CLIENT_SHORT}_analysis to ROLE ${CLIENT_SHORT}_an;

   create database if not exists ${CLIENT_SHORT}_etl location 'hdfs://${HDFS_NAME_SERVICE}/${ROOTDIR}/etl';
   grant all on database ${CLIENT_SHORT}_etl to ROLE ${CLIENT_SHORT}_dm;
   grant select on database ${CLIENT_SHORT}_etl to ROLE ${CLIENT_SHORT}_an;

   create database if not exists ${CLIENT_SHORT}_tmp location 'hdfs://${HDFS_NAME_SERVICE}/${ROOTDIR}/tmp';
   grant all on database ${CLIENT_SHORT}_tmp to ROLE ${CLIENT_SHORT}_dm;
   grant select on database ${CLIENT_SHORT}_tmp to ROLE ${CLIENT_SHORT}_an;

   create database if not exists ${CLIENT_SHORT}_segmentations location 'hdfs://${HDFS_NAME_SERVICE}/${ROOTDIR}/segmentations';
   grant all on database ${CLIENT_SHORT}_segmentations to ROLE ${CLIENT_SHORT}_dm;
   grant select on database ${CLIENT_SHORT}_segmentations to ROLE ${CLIENT_SHORT}_an;

   grant all on URI "${URI_BASE}/inbound" to role ${CLIENT_SHORT}_dm;
   grant all on URI "${URI_BASE}/inbound_tmp" to role ${CLIENT_SHORT}_dm;

   grant all on URI "${URI_BASE}/adm" to role ${CLIENT_SHORT}_dm;
   grant all on URI "${URI_BASE}/etl" to role ${CLIENT_SHORT}_dm;
   grant all on URI "${URI_BASE}/tmp" to role ${CLIENT_SHORT}_dm;
   grant all on URI "${URI_BASE}/segmentations" to role ${CLIENT_SHORT}_dm;
   grant all on URI "${URI_BASE}/analysis" to role ${CLIENT_SHORT}_an;
   grant all on URI "${URI_BASE}/analysis" to role ${CLIENT_SHORT}_dm;

   !quit
EOF
) || {  log4dh_error "ERROR: Error applying grants to databases."; exit 1 ; }

if [[ "$OS_DM_GROUP" != "" ]]; then
ONSHORE="_onshore"
log4dh_info "Creating onshore databases and setting the sentry roles."
( /usr/bin/beeline -u "jdbc:hive2://${HIVE_SERVER}:10000/default;principal=hive/${HIVE_SERVER}.dunnhumby.co.uk@DUNNHUMBY.CO.UK" <<EOF
   create role ${CLIENT_SHORT}_os_dm;
   GRANT ROLE ${CLIENT_SHORT}_os_dm TO GROUP ${OS_DM_GROUP};

   create database if not exists ${CLIENT_SHORT}_${SUFFIX}${ONSHORE} location 'hdfs://${HDFS_NAME_SERVICE}${DIR_ONSHORE}';
   grant all on database ${CLIENT_SHORT}_${SUFFIX}${ONSHORE} to ROLE ${CLIENT_SHORT}_os_dm;

   create database if not exists ${CLIENT_SHORT}_${SUFFIX}${ONSHORE}_tmp location 'hdfs://${HDFS_NAME_SERVICE}${DIR_ONSHORE}_tmp';
   grant all on database ${CLIENT_SHORT}_${SUFFIX}${ONSHORE}_tmp to ROLE ${CLIENT_SHORT}_os_dm;

   grant all on URI "${URI_BASE}/inbound${ONSHORE}" to role ${CLIENT_SHORT}_os_dm;
   grant all on URI "${URI_BASE}/inbound${ONSHORE}_tmp" to role ${CLIENT_SHORT}_os_dm;

   !quit
EOF
) || { log4dh_error "ERROR: For onshore, Creating roles and granting to groups failed."; exit 1 ; }
fi


if [[ "$HAS_DISCOVERY" != "" ]]; then
log4dh_info "Create discovery database and providing permissions."
DISCOVERY="discovery"
( /usr/bin/beeline -u "jdbc:hive2://${HIVE_SERVER}:10000/default;principal=hive/${HIVE_SERVER}.dunnhumby.co.uk@DUNNHUMBY.CO.UK" <<EOF

   create database if not exists ${CLIENT_SHORT}_${DISCOVERY} location 'hdfs://${HDFS_NAME_SERVICE}${DIR_DISCOVERY}';
   grant all on database ${CLIENT_SHORT}_${DISCOVERY} to ROLE ${CLIENT_SHORT}_dm;
   grant select on database ${CLIENT_SHORT}_${DISCOVERY} to ROLE ${CLIENT_SHORT}_an;

   grant all on URI "${URI_BASE}/${DISCOVERY}" to role ${CLIENT_SHORT}_dm;
   grant select on URI "${URI_BASE}/${DISCOVERY}" to role ${CLIENT_SHORT}_an;

   !quit
EOF
) || { log4dh_error "ERROR: For onshore, Creating roles and granting to groups failed."; exit 1 ; }
fi

log4dh_info "Environment created successfully. Script last updated- Aug 03, 2016"
