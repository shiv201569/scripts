from pyspark import SparkConf
from pyspark import SparkContext,HiveContext
conf = SparkConf()
conf.setMaster('yarn')
conf.setAppName('spark-test')
sc = SparkContext()
sqlContext= HiveContext(sc)
# Latest egg file from master.
sc.addPyFile("hdfs:///user/nitinm/domain-1.0-py2.7.egg")
sc.addPyFile("hdfs:///user/nitinm/coop_ch-1.0-py2.7.egg")

import logging
reload(logging)
logging.basicConfig(format="%(asctime)s [%(funcName)s:%(lineno)d] %(message)s", 
                    level=logging.NOTSET, 
                    datefmt='%I:%M:%S')


import matplotlib
matplotlib.use('PDF')

import domain
import coop_ch
client = coop_ch.client.Client('dev',sc,sqlContext)
client.calendar().data.select("fis_week_id", "date_id").show(2, False)
