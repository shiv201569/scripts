#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import pandas as pd
import time
import sqlalchemy as sa
import logging
import math


# # In[4]:


# proxy = input("Enter proxy (like:AN_RT_WS15)  :")
proxy = "AN_RT_WS01"
import getpass
# password = getpass.getpass()
engine = sa.create_engine("oracle+cx_oracle://[AN_RT_WS01]:@exa_gbtthprdd_an")


# In[2]:


pd.read_sql("""select * from store_dim_c where rownum<10""",engine).to_csv('sample.csv',index=False)

